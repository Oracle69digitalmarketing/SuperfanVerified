// globals.ts
import { Buffer } from 'buffer';
global.Buffer = Buffer;

